import { IsString, IsEmail, IsOptional, IsNumber, IsDate, IsArray } from 'class-validator';

export class CreateUserDto {
    @IsString()
    name: string;

    @IsEmail()
    email: string;

    @IsString()
    password: string;

    @IsString()
    phone: string;

    @IsString()
    cpf: string;

    @IsString()
    gender: string;

    @IsOptional()
    @IsDate()
    bornDate?: Date;

    @IsString()
    profilePic: string;

    @IsNumber()
    role: number;

    @IsOptional()
    @IsNumber()
    premiumTier?: number;

    @IsOptional()
    @IsArray()
    history?: string[];

    @IsOptional()
    work?: any;
}
