import { IsEmail, IsNotEmpty, IsOptional, IsString, IsNumber, IsArray, ArrayNotEmpty, IsBoolean, IsDate } from 'class-validator';

export class CreateCostumerDto {
    @IsNotEmpty()
    @IsString()
    name: string;

    @IsOptional()
    role: number;

    @IsEmail()
    email: string;

    @IsNotEmpty()
    password: string;

    @IsNotEmpty()
    @IsString()
    phone: string;

    @IsOptional()
    @IsString()
    cpf?: string;

    @IsOptional()
    @IsString()
    gender: string;

    @IsOptional()
    @IsDate()
    bornDate: Date

    @IsOptional()
    @IsString()
    profilePic?: string;

    @IsOptional()
    @IsNumber()
    premiumTier?: number;

    @IsOptional()
    @IsArray()
    @IsString({ each: true })
    history?: string[];
}
